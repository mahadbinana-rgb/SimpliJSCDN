import test from 'node:test';
import assert from 'node:assert/strict';
import { compile } from '../src/compiler.js';

test('variables and changes compile', () => {
  const js = compile(`\nset score to 100\nincrease score by 10\nshow score\n`);
  assert.match(js, /let score = 100/);
  assert.match(js, /score \+= 10/);
  assert.match(js, /console\.log\(score\)/);
});

test('conditions compile to JavaScript comparisons', () => {
  const js = compile(`if score is greater than or equal to 100:\n    show "won"\notherwise:\n    show "lost"`);
  assert.match(js, /score >= 100/);
  assert.match(js, /else/);
});

test('HTML interpolation compiles into a template literal', () => {
  const js = compile(`add HTML to "#notes":\n    <div class="note">{note.name}</div>`);
  assert.match(js, /note\.name/);
  assert.match(js, /insertAdjacentHTML/);
});

test('javascript blocks pass through without conversion', () => {
  const js = compile(`javascript:\n    const x = await fetch('/test');\n    console.log(x);`);
  assert.match(js, /const x = await fetch/);
  assert.match(js, /console\.log\(x\)/);
});

test('function definitions, returns, and object methods compile', () => {
  const js = compile(`function add with a, b:\n    return a + b\nset answer to run add with 5, 10\ncreate user:\n    name: "Mahad"\nend user\nadd function greet to user with who:\n    show this.name + who\nrun user.greet with "!"`);
  assert.match(js, /function add\(a, b\)/);
  assert.match(js, /return a \+ b/);
  assert.match(js, /answer = add\(5, 10\)/);
  assert.match(js, /let user = \{"name": "Mahad"\}/);
  assert.match(js, /user\["greet"\] = function\(who\)/);
  assert.match(js, /user\.greet\("!"\)/);
});

test('object and array helpers compile', () => {
  const js = compile(`set user to {name: "Mahad", age: 18}\nset keys to object keys of user\nset hasName to user has property "name"\nset oldName to property value of user`);
  assert.match(js, /Object\.keys\(user\)/);
  assert.match(js, /hasOwnProperty/);
});

test('array conveniences and full method bridge compile', () => {
  const js = compile(`set fruits to ["Apple", "Banana"]\nadd "Orange" to fruits\nset removed to splice fruits starting at 1 removing 1\nset doubled to map numbers using number => number * 2\nset custom to use "toString" on fruits`);
  assert.match(js, /fruits\.push\("Orange"\)/);
  assert.match(js, /fruits\.splice\(1, 1\)/);
  assert.match(js, /numbers\.map\(function\(number\)/);
  assert.match(js, /fruits\["toString"\]\(\)/);
});

test('DOM English API compiles', () => {
  const js = compile(`set name to saved "username"\nset "#title" inner text to name\nset "#box" background color to "red"\nset value to value of "#input"\nset kids to children of "#box"\nset first to first child of "#box"\nset "#box" attribute "data-id" to "123"\nremove attribute "disabled" from "#button"\nclear children of "#box"`);
  assert.match(js, /easyJSReadStorage\(localStorage, "username"\)/);
  assert.match(js, /\["innerText"\] = name/);
  assert.match(js, /backgroundColor/);
  assert.match(js, /value/);
  assert.match(js, /children/);
  assert.match(js, /firstElementChild/);
  assert.match(js, /setAttribute/);
  assert.match(js, /removeAttribute/);
  assert.match(js, /replaceChildren/);
});

test('full localStorage CRUD helpers compile', () => {
  const js = compile(`save user as "currentUser"\nset user2 to saved "currentUser"\nset raw to saved "currentUser" raw\nset keys to saved keys\nset count to saved data count\nif saved "currentUser" exists:\n    delete saved "currentUser"\nclear saved data`);
  assert.match(js, /easyJSSave\(localStorage/);
  assert.match(js, /easyJSReadStorage\(localStorage/);
  assert.match(js, /localStorage\.getItem/);
  assert.match(js, /localStorage\.length/);
  assert.match(js, /easyJSHasStorage\(localStorage/);
  assert.match(js, /localStorage\.removeItem/);
  assert.match(js, /localStorage\.clear/);
});

test('generic methods and object static methods stay native', () => {
  const js = compile(`set result to use "toUpperCase" on name\nset merged to object assign first, second\nset same to object is first, second`);
  assert.match(js, /name\["toUpperCase"\]\(\)/);
  assert.match(js, /Object\.assign\(first, second\)/);
  assert.match(js, /Object\.is\(first, second\)/);
});

test('show a selector is a DOM visibility command', () => {
  const js = compile(`show "#menu"\nhide "#panel"\ntoggle "#modal"`);
  assert.match(js, /hidden = false/);
  assert.match(js, /hidden = true/);
});


test('math, prompt and date/time helpers stay readable and browser-local', () => {
  const js = compile(`set answer to ask("Enter your name")
set confirmed to askYesNo("Continue?")
set value to random()
set dice to randomBetween(1, 6)
set rounded to roundUp(4.2)
set area to power(4, 2)
set root to squareRoot(16)
set current to now()
set localDate to today()
set localTime to timeNow()
set year to currentYear()
set japanDate to dateIn("Japan")
set pakistanTime to timeIn("Pakistan")
set worldTime to dateTimeIn("Asia/Tokyo")`);
  assert.match(js, /ask\("Enter your name"\)/);
  assert.match(js, /askYesNo\("Continue\?"\)/);
  assert.match(js, /random\(\)/);
  assert.match(js, /randomBetween\(1, 6\)/);
  assert.match(js, /roundUp\(4.2\)/);
  assert.match(js, /power\(4, 2\)/);
  assert.match(js, /squareRoot\(16\)/);
  assert.match(js, /dateIn\("Japan"\)/);
  assert.match(js, /timeIn\("Pakistan"\)/);
  assert.match(js, /dateTimeIn\("Asia\/Tokyo"\)/);
});

test('form input helpers and DOM actions compile', () => {
  const js = compile(`set name to value of "#name"
set checked to checked of ".agree"
set valid to valid of "input"
set message to validation message of "#email"
set data to form data of "#form"
validate "#form"
focus "#name"
prevent default`);
  assert.match(js, /\["value"\]/);
  assert.match(js, /\["checked"\]/);
  assert.match(js, /easyJSIsValid/);
  assert.match(js, /validationMessage/);
  assert.match(js, /easyJSFormData/);
  assert.match(js, /reportValidity/);
  assert.match(js, /preventDefault/);
});

test('friendly typo detection points at the source line', () => {
  assert.throws(() => compile(`set name to "Mahad"
shwo "Hello"`), /Line 2:.*Did you mean 'show'/s);
});

test('full native Object and Array static methods remain reachable', () => {
  const js = compile(`set keys to use object "keys" with user
set list to use array "from" with nodes
use object "freeze" with user
use array "isArray" with list`);
  assert.match(js, /Object\["keys"\]\(user\)/);
  assert.match(js, /Array\["from"\]\(nodes\)/);
  assert.match(js, /Object\["freeze"\]\(user\)/);
  assert.match(js, /Array\["isArray"\]\(list\)/);
});

test('exact repeat + HTML example parses and does not treat show text as selector', () => {
  const js = compile(`repeat 1 times:
    add HTML to "#notes":
        <article class="note">
            <h2>Mahad</h2>
            <p>13</p>
        </article>`);
  assert.match(js, /for \(let __simplijs_i/);
  assert.match(js, /insertAdjacentHTML/);
});

test('create element and add shortcut both compile', () => {
  const js = compile(`create element "div" called note
set note class to "note"
set note text to "Hello"
add child note to "#notes"
add note to "#notes"`);
  assert.match(js, /document\.createElement\("div"\)/);
  assert.match(js, /appendEasyJS/);
});

test('multiline arrays can contain multiple objects and support object CRUD', () => {
  const js = compile(`set users to [
    { name: "Mahad", age: 13 },
    { name: "Ali", age: 18 }
]
set firstUser to item 1 from users
set firstName to property "name" of firstUser
set property "age" of item 1 in users to 14
set item 2 in users to { name: "Ahmed", age: 20 }
insert { name: "Sara", age: 21 } at 2 in users
remove item 3 from users
clear array users`);
  assert.match(js, /let users = \[/);
  assert.match(js, /users\[Number\(1\) - 1\]\["age"\] = 14/);
  assert.match(js, /users\.splice\(Number\(2\) - 1, 0/);
  assert.match(js, /users\.splice\(Number\(3\) - 1, 1\)/);
});

test('stored arrays and objects support direct CRUD', () => {
  const js = compile(`set users to [{ name: "Mahad", age: 13 }, { name: "Ali", age: 18 }]
save users as "users"
add { name: "Ahmed", age: 20 } to saved "users"
set property "age" of item 1 in saved "users" to 14
set item 2 in saved "users" to { name: "Sara", age: 21 }
remove item 2 from saved "users"
set profile to { name: "Mahad", age: 18 }
save profile as "profile"
set property "age" of saved "profile" to 19
set age to property "age" of saved "profile"
remove property "age" from saved "profile"`);
  assert.match(js, /easyJSUpdateStoredValue\(localStorage, "users"/);
  assert.match(js, /easyJSUpdateStoredValue\(localStorage, "profile"/);
  assert.match(js, /easyJSReadStorage\(localStorage, "profile"\)/);
});

test('wait, timeout and interval helpers compile to native timers', () => {
  const js = compile(`wait(2)
after 2 seconds as timeout:
    console.log("done")
every 1 second as interval:
    console.log("tick")
clear timer interval`);
  assert.match(js, /await wait\(2\)/);
  assert.match(js, /setTimeout/);
  assert.match(js, /setInterval/);
  assert.match(js, /clearInterval\(interval\)/);
});
