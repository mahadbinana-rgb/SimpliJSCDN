export function indentOf(line) {
  const match = /^( *)/.exec(line);
  return match ? match[1].length : 0;
}

export function isBlank(line) {
  return /^\s*$/.test(line);
}

export function stripTrailingWhitespace(lines) {
  while (lines.length && isBlank(lines[lines.length - 1])) lines.pop();
  return lines;
}

export function normalizeExpression(value) {
  return value.trim();
}

export function escapeTemplateRaw(text) {
  return text.replace(/`/g, '\\`').replace(/\\(?![${])/g, '\\\\');
}

export function transformInterpolations(text) {
  let out = '';
  let i = 0;
  while (i < text.length) {
    if (text[i] === '{') {
      let depth = 1;
      let j = i + 1;
      let quote = null;
      while (j < text.length && depth > 0) {
        const c = text[j];
        if (quote) {
          if (c === '\\') j += 2;
          else if (c === quote) { quote = null; j += 1; }
          else j += 1;
          continue;
        }
        if (c === '"' || c === "'" || c === '`') quote = c;
        else if (c === '{') depth += 1;
        else if (c === '}') depth -= 1;
        j += 1;
      }
      if (depth === 0) {
        const expr = text.slice(i + 1, j - 1).trim();
        out += `\${${expr}}`;
        i = j;
        continue;
      }
    }
    out += text[i];
    i += 1;
  }
  return escapeTemplateRaw(out);
}

export function quote(value) {
  return JSON.stringify(value);
}

export function splitTopLevelCommas(value) {
  const parts = [];
  let start = 0;
  let depth = 0;
  let quoteChar = null;
  for (let i = 0; i < value.length; i++) {
    const c = value[i];
    if (quoteChar) {
      if (c === '\\') i += 1;
      else if (c === quoteChar) quoteChar = null;
      continue;
    }
    if (c === '"' || c === "'" || c === '`') { quoteChar = c; continue; }
    if ('([{'.includes(c)) depth += 1;
    else if (')]}'.includes(c)) depth -= 1;
    else if (c === ',' && depth === 0) {
      parts.push(value.slice(start, i).trim());
      start = i + 1;
    }
  }
  const last = value.slice(start).trim();
  if (last) parts.push(last);
  return parts;
}

export function parseCallArguments(text) {
  return splitTopLevelCommas(text);
}
