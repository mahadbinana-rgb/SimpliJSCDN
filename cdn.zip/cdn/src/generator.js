import { transformInterpolations } from './utils.js';

export class CodeGenerator {
  constructor() {
    this.scopes = [new Set()];
    this.timerCounter = 0;
  }

  generate(ast) {
    const body = ast.body.map(node => this.emitStatement(node)).filter(Boolean).join('\n');
    return `(async function(){\n${indent(body)}\n})().catch(function(error){ console.error('[SimpliJS runtime]', error); });\n`;
  }

  declaration(name) {
    for (let i = this.scopes.length - 1; i >= 0; i -= 1) {
      if (this.scopes[i].has(name)) return '';
    }
    this.scopes[this.scopes.length - 1].add(name);
    return 'let ';
  }

  withScope(seed, callback) {
    const scope = new Set(seed || []);
    this.scopes.push(scope);
    try { return callback(); } finally { this.scopes.pop(); }
  }

  emitBody(nodes) {
    return nodes.map(n => this.emitStatement(n)).filter(Boolean).join('\n');
  }

  emitStatement(node) {
    switch (node.type) {
      case 'Set': return `${this.declaration(node.name)}${node.name} = ${node.expression};`;
      case 'Run': return `${node.name}(${node.args.join(', ')});`;
      case 'RunExpression': return `${this.declaration(node.name)}${node.name} = ${node.callee}(${node.args.join(', ')});`;
      case 'Return': return node.expression ? `return ${node.expression};` : 'return;';

      case 'ArrayAdd': return `${node.name}.push(${node.expression});`;
      case 'ArrayRemove': return `${node.name} = ${node.name}.filter(function(__item){ return __item !== ${node.expression}; });`;
      case 'ArrayGet': return `${this.declaration(node.name)}${node.name} = ${node.array}[Number(${node.index}) - 1];`;
      case 'ArraySetItem': return `${node.array}[Number(${node.index}) - 1] = ${node.expression};`;
      case 'ArrayInsert': return `${node.array}.splice(Number(${node.index}) - 1, 0, ${node.expression});`;
      case 'ArrayRemoveAt': return `${node.array}.splice(Number(${node.index}) - 1, 1);`;
      case 'ArrayClear': return `${node.array}.splice(0, ${node.array}.length);`;
      case 'Length': return `${this.declaration(node.name)}${node.name} = ${node.array}.length;`;
      case 'ArrayMethod': return `${this.declaration(node.name)}${node.name} = ${node.target}.${methodName(node.method)}(${node.args.join(', ')});`;
      case 'ArrayDiscardMethod': return `${node.target}.${methodName(node.method)}(${node.args.join(', ')});`;
      case 'ArrayCallback': {
        const method = methodName(node.method);
        return `${this.declaration(node.name)}${node.name} = ${node.target}.${method}(function(${node.parameter}){ return ${node.expression}; });`;
      }
      case 'ArrayReduce': return `${this.declaration(node.name)}${node.name} = ${node.target}.reduce(function(${node.accumulator}, ${node.parameter}){ return ${node.expression}; }, ${node.initial});`;
      case 'MethodCall': return `${this.declaration(node.name)}${node.name} = ${node.target}[${JSON.stringify(node.method)}](${node.args.join(', ')});`;
      case 'MethodDiscard': return `${node.target}[${JSON.stringify(node.method)}](${node.args.join(', ')});`;
      case 'StaticMethodCall': return `${this.declaration(node.name)}${node.name} = ${node.object}[${JSON.stringify(node.method)}](${node.args.join(', ')});`;
      case 'StaticMethodDiscard': return `${node.object}[${JSON.stringify(node.method)}](${node.args.join(', ')});`;

      case 'ObjectKeys': return `${this.declaration(node.name)}${node.name} = Object.keys(${node.object});`;
      case 'ObjectValues': return `${this.declaration(node.name)}${node.name} = Object.values(${node.object});`;
      case 'ObjectEntries': return `${this.declaration(node.name)}${node.name} = Object.entries(${node.object});`;
      case 'ObjectGetProp': return `${this.declaration(node.name)}${node.name} = ${node.object}[${JSON.stringify(node.property)}];`;
      case 'ObjectSetProp': return `${node.object}[${JSON.stringify(node.property)}] = ${node.expression};`;
      case 'ObjectDeleteProp': return `delete ${node.object}[${JSON.stringify(node.property)}];`;
      case 'ObjectHasProp': return `${this.declaration(node.name)}${node.name} = Object.prototype.hasOwnProperty.call(${node.object}, ${JSON.stringify(node.property)});`;
      case 'ObjectStatic': return `${this.declaration(node.name)}${node.name} = Object.${node.method}(${node.object});`;
      case 'ObjectStaticArgs': return `${this.declaration(node.name)}${node.name} = Object.${node.method}(${node.args.join(', ')});`;
      case 'CreateObject': {
        const objectLiteral = `{${node.properties.map(p => `${JSON.stringify(p.key)}: ${p.value}`).join(', ')}}`;
        const lines = [`${this.declaration(node.name)}${node.name} = ${objectLiteral};`];
        for (const method of node.methods) {
          const body = this.withScope(method.args, () => this.emitBody(method.body));
          lines.push(`${node.name}[${JSON.stringify(method.name)}] = function(${method.args.join(', ')}) {\n${indent(body)}\n};`);
        }
        return lines.join('\n');
      }
      case 'ObjectMethod': {
        const body = this.withScope(node.args, () => this.emitBody(node.body));
        return `${node.object}[${JSON.stringify(node.name)}] = function(${node.args.join(', ')}) {\n${indent(body)}\n};`;
      }

      case 'Change': return `${targetCode(node.target)} ${op(node.operation)}= ${node.value};`;
      case 'Show': return `console.log(${node.expression});`;
      case 'Alert': return `alert(${node.expression});`;
      case 'If': return node.branches.map((branch, i) => {
        const head = branch.condition == null ? 'else' : (i === 0 ? `if (${compareCondition(branch.condition)})` : `else if (${compareCondition(branch.condition)})`);
        return `${head} {\n${indent(this.emitBody(branch.body))}\n}`;
      }).join(' ');
      case 'Repeat': return `for (let __simplijs_i = 0; __simplijs_i < (${node.count}); __simplijs_i += 1) {\n${indent(this.emitBody(node.body))}\n}`;
      case 'While': return `while (${compareCondition(node.condition)}) {\n${indent(this.emitBody(node.body))}\n}`;
      case 'ForOf': return `for (const ${node.item} of ${node.iterable}) {\n${indent(this.emitBody(node.body))}\n}`;
      case 'Wait': return `await wait(${node.expression});`;
      case 'Timeout': {
        const body = this.withScope(['__timeout'], () => this.emitBody(node.body));
        const delay = delayExpression(node.delay, node.unit);
        const handle = node.name ? `${this.declaration(node.name)}${node.name}` : `${this.declaration(`__simplijs_timeout_${++this.timerCounter}`)}__simplijs_timeout_${this.timerCounter}`;
        return `${handle} = setTimeout(function(){\n${indent(body)}\n}, ${delay});`;
      }
      case 'Interval': {
        const body = this.withScope(['__interval'], () => this.emitBody(node.body));
        const delay = delayExpression(node.delay, node.unit);
        const handle = node.name ? `${this.declaration(node.name)}${node.name}` : `${this.declaration(`__simplijs_interval_${++this.timerCounter}`)}__simplijs_interval_${this.timerCounter}`;
        return `${handle} = setInterval(function(){\n${indent(body)}\n}, ${delay});`;
      }
      case 'StopTimer': return `clearTimeout(${node.name}); clearInterval(${node.name});`;
      case 'Function': {
        const body = this.withScope(node.args, () => this.emitBody(node.body));
        return `function ${node.name}(${node.args.join(', ')}) {\n${indent(body)}\n}`;
      }
      case 'Event': {
        const target = targetCode(node.target);
        const body = this.withScope(['event'], () => this.emitBody(node.body));
        if (node.event === 'DOMContentLoaded') return `document.addEventListener('DOMContentLoaded', function(event) {\n${indent(body)}\n});`;
        return `${eventTargets(target)}.forEach(function(__el){ __el.addEventListener(${JSON.stringify(node.event)}, function(event){\n${indent(body)}\n}); });`;
      }
      case 'PreventDefault': return `if (typeof event !== 'undefined' && event && event.preventDefault) event.preventDefault();`;
      case 'RawJS': return node.code;

      case 'DOMSetText': return `${allTargets(node.target)}.forEach(function(__el){ __el[${JSON.stringify(node.property || 'textContent')}] = ${node.expression}; });`;
      case 'DOMSetHTML': return `${allTargets(node.target)}.forEach(function(__el){ __el.innerHTML = ${node.expression}; });`;
      case 'DOMSetProp': return `${allTargets(node.target)}.forEach(function(__el){ __el[${JSON.stringify(node.property)}] = ${node.expression}; });`;
      case 'DOMStyle': return `${allTargets(node.target)}.forEach(function(__el){ __el.style[${JSON.stringify(node.property)}] = ${node.expression}; });`;
      case 'DOMCSSVar': return `${allTargets(node.target)}.forEach(function(__el){ __el.style.setProperty(${JSON.stringify(node.property)}, ${node.expression}); });`;
      case 'DOMVisibility': return `${allTargets(node.target)}.forEach(function(__el){ ${visibilityCode(node.action)} });`;
      case 'DOMClass': return `${allTargets(node.target)}.forEach(function(__el){ __el.classList.${node.action === 'add' ? 'add' : node.action === 'remove' ? 'remove' : 'toggle'}(${node.className}); });`;
      case 'DOMRemove': return `${allTargets(node.target)}.forEach(function(__el){ __el.remove(); });`;
      case 'DOMClear': return `${allTargets(node.target)}.forEach(function(__el){ __el.replaceChildren(); });`;
      case 'DOMAppend': return `appendEasyJS(${targetCode(node.parent)}, ${targetCode(node.child)});`;
      case 'DOMPrepend': return `appendEasyJS(${targetCode(node.parent)}, ${targetCode(node.child)}, true);`;
      case 'DOMRemoveChild': return `removeEasyJSChild(${targetCode(node.parent)}, ${targetCode(node.child)});`;
      case 'DOMSetAttribute': return `${allTargets(node.target)}.forEach(function(__el){ __el.setAttribute(${JSON.stringify(node.attribute)}, ${node.expression}); });`;
      case 'DOMRemoveAttribute': return `${allTargets(node.target)}.forEach(function(__el){ __el.removeAttribute(${JSON.stringify(node.attribute)}); });`;
      case 'DOMSetData': return `${allTargets(node.target)}.forEach(function(__el){ __el.dataset[${JSON.stringify(node.name)}] = ${node.expression}; });`;
      case 'DOMGetData': return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)})?.dataset?.[${JSON.stringify(node.key)}];`;
      case 'RawSetTarget': return `${targetCode(node.target)} = ${node.expression};`;
      case 'GetAttribute': return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)})?.getAttribute(${JSON.stringify(node.attribute)});`;
      case 'DOMGetProp': return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)})?.[${JSON.stringify(node.property)}];`;
      case 'DOMGetChildren': return `${this.declaration(node.name)}${node.name} = [...(getEasyJSElement(${targetCode(node.target)})?.children || [])];`;
      case 'DOMGetChild': return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)})?.${node.which === 'first' ? 'firstElementChild' : 'lastElementChild'};`;
      case 'DOMGetRelation': {
        const prop = node.relation === 'parent' ? 'parentElement' : node.relation === 'next sibling' ? 'nextElementSibling' : 'previousElementSibling';
        return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)})?.${prop};`;
      }
      case 'DOMValidity': return `${this.declaration(node.name)}${node.name} = easyJSIsValid(${targetCode(node.target)});`;
      case 'DOMFormData': return `${this.declaration(node.name)}${node.name} = easyJSFormData(${targetCode(node.target)});`;
      case 'DOMValidate': return `getEasyJSElement(${targetCode(node.target)})?.reportValidity?.();`;
      case 'DOMAction': return `${allTargets(node.target)}.forEach(function(__el){ if (__el && typeof __el[${JSON.stringify(node.action)}] === 'function') __el[${JSON.stringify(node.action)}](); });`;
      case 'GetElement': return `${this.declaration(node.name)}${node.name} = getEasyJSElement(${targetCode(node.target)});`;
      case 'GetElements': return `${this.declaration(node.name)}${node.name} = getEasyJSElements(${targetCode(node.target)});`;
      case 'FindElement': return `${this.declaration(node.name || '__simplijsFound')}${node.name || '__simplijsFound'} = getEasyJSElement(${targetCode(node.selector)}, ${node.inside ? targetCode(node.inside) : 'undefined'});`;
      case 'FindElements': return `${this.declaration(node.name || '__simplijsFoundAll')}${node.name || '__simplijsFoundAll'} = getEasyJSElements(${targetCode(node.selector)}, ${node.inside ? targetCode(node.inside) : 'undefined'});`;
      case 'CreateElement': return `${this.declaration(node.name)}${node.name} = document.createElement(${JSON.stringify(node.tag)});`;
      case 'AddHTML': return `${allTargets(node.target)}.forEach(function(__el){ __el.insertAdjacentHTML('beforeend', \`${transformInterpolations(node.template)}\`); });`;

      case 'FetchJSON': return `${this.declaration(node.name)}${node.name} = await fetch(${node.url}).then(function(__r){ if(!__r.ok) throw new Error('Request failed: ' + __r.status); return __r.json(); });`;
      case 'PostJSON': {
        const object = `{${node.body.map(item => `${JSON.stringify(item.key)}: ${item.value}`).join(', ')}}`;
        return `${this.declaration(node.name)}${node.name} = await fetch(${node.url}, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(${object}) }).then(function(__r){ if(!__r.ok) throw new Error('Request failed: ' + __r.status); return __r.json(); });`;
      }

      case 'Save': return `easyJSSave(${node.storage}, ${JSON.stringify(node.key)}, ${node.expression});`;
      case 'Load': return `${this.declaration(node.name)}${node.name} = easyJSReadStorage(${node.storage}, ${JSON.stringify(node.key)});`;
      case 'LoadRaw': return `${this.declaration(node.name)}${node.name} = ${node.storage}.getItem(${JSON.stringify(node.key)});`;
      case 'StorageKeys': return `${this.declaration(node.name)}${node.name} = easyJSStorageKeys(${node.storage});`;
      case 'StorageLength': return `${this.declaration(node.name)}${node.name} = ${node.storage}.length;`;
      case 'DeleteSaved': return `${node.storage}.removeItem(${JSON.stringify(node.key)});`;
      case 'StorageArrayAdd': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an array.');
  __value.push(${node.expression});
  return __value;
});`;
      case 'StorageArrayRemoveAt': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an array.');
  __value.splice(Number(${node.index}) - 1, 1);
  return __value;
});`;
      case 'StorageArraySetItem': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an array.');
  __value[Number(${node.index}) - 1] = ${node.expression};
  return __value;
});`;
      case 'StorageArraySetProperty': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an array.');
  const __item = __value[Number(${node.index}) - 1];
  if (!__item || typeof __item !== 'object') throw new Error('That saved array item is not an object.');
  __item[${JSON.stringify(node.property)}] = ${node.expression};
  return __value;
});`;
      case 'StorageObjectSetProperty': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!__value || typeof __value !== 'object' || Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an object.');
  __value[${JSON.stringify(node.property)}] = ${node.expression};
  return __value;
});`;
      case 'StorageObjectDeleteProperty': return `easyJSUpdateStoredValue(${node.storage}, ${JSON.stringify(node.key)}, function(__value){
  if (!__value || typeof __value !== 'object' || Array.isArray(__value)) throw new Error('The saved value "' + ${JSON.stringify(node.key)} + '" is not an object.');
  delete __value[${JSON.stringify(node.property)}];
  return __value;
});`;
      case 'StorageObjectGetProperty': return `${this.declaration(node.name)}${node.name} = easyJSReadStorage(${node.storage}, ${JSON.stringify(node.key)})?.[${JSON.stringify(node.property)}];`;
      case 'ClearSaved': return `${node.storage}.clear();`;
      


      default: throw new Error(`Unknown SimpliJS node: ${node.type}`);
    }
  }
}

function delayExpression(value, unit) {
  const multiplier = {
    ms: 1, milliseconds: 1,
    s: 1000, second: 1000, seconds: 1000,
    m: 60000, minute: 60000, minutes: 60000,
    h: 3600000, hour: 3600000, hours: 3600000
  }[String(unit).toLowerCase()] || 1000;
  return `(Number(${value}) * ${multiplier})`;
}

function indent(value) {
  if (!value) return '  ';
  return value.split('\n').map(line => line ? `  ${line}` : line).join('\n');
}
function op(operation) { return ({ increase: '+', decrease: '-', multiply: '*', divide: '/' })[operation] || '+'; }
function methodName(method) {
  const map = {
    'index of': 'indexOf', indexof: 'indexOf', includes: 'includes', splice: 'splice', slice: 'slice', join: 'join',
    reverse: 'reverse', sort: 'sort', pop: 'pop', shift: 'shift', unshift: 'unshift', at: 'at',
    'find index': 'findIndex', findindex: 'findIndex'
  };
  return map[method] || method;
}
function compareCondition(condition) {
  let c = condition.trim();
  const replacements = [
    [/^saved\s+(["'].*?["'])\s+exists$/i, 'easyJSHasStorage(localStorage, $1)'],
    [/^saved\s+(["'].*?["'])\s+exists\s+in\s+this\s+session$/i, 'easyJSHasStorage(sessionStorage, $1)'],
    [/\bis\s+greater\s+than\s+or\s+equal\s+to\b/gi, '>='],
    [/\bis\s+less\s+than\s+or\s+equal\s+to\b/gi, '<='],
    [/\bis\s+greater\s+than\b/gi, '>'],
    [/\bis\s+less\s+than\b/gi, '<'],
    [/\bis\s+not\s+equal\s+to\b/gi, '!=='],
    [/\bis\s+equal\s+to\b/gi, '===']
  ];
  for (const [pattern, replacement] of replacements) c = c.replace(pattern, replacement);
  return c;
}
function targetCode(target) { return target.type === 'selector' ? `getEasyJSElement(${JSON.stringify(target.value)})` : target.value; }
function allTargets(target) { return target.type === 'selector' ? `getEasyJSElements(${JSON.stringify(target.value)})` : `easyJSNormalizeTargets(${target.value})`; }
function eventTargets(target) { return `easyJSEventTargets(${target})`; }
function visibilityCode(action) {
  if (action === 'show') return `__el.hidden = false; __el.style.removeProperty('display');`;
  if (action === 'hide') return `__el.hidden = true;`;
  return `__el.hidden = !__el.hidden;`;
}
