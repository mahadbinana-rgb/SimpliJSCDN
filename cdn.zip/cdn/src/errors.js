const COMMAND_WORDS = [
  'set', 'show', 'alert', 'ask', 'askYesNo', 'save', 'delete', 'remove', 'clear',
  'change', 'increase', 'decrease', 'multiply', 'divide', 'if', 'otherwise', 'repeat',
  'while', 'for', 'function', 'run', 'return', 'create', 'add', 'push', 'pop', 'shift',
  'unshift', 'reverse', 'sort', 'use', 'when', 'find', 'get', 'post', 'hide', 'toggle',
  'focus', 'blur', 'click', 'validate', 'prevent', 'reload', 'go', 'replace', 'open',
  'javascript', 'random', 'randomBetween', 'round', 'roundUp', 'roundDown', 'absolute',
  'power', 'squareRoot', 'min', 'max', 'pi', 'now', 'today', 'timeNow', 'currentYear',
  'dateIn', 'timeIn', 'dateTimeIn', 'wait', 'after', 'every', 'stop', 'insert'
];

export class SimpliJSError extends Error {
  constructor(message, line = null, column = null, sourceLine = null) {
    const location = line == null ? '' : `Line ${line}${column == null ? '' : `, column ${column}`}`;
    const source = sourceLine == null || !String(sourceLine).trim() ? '' : `\n\n  ${String(sourceLine).trim()}`;
    super(`${location ? `${location}: ` : ''}${message}${source}`);
    this.name = 'SimpliJSError';
    this.line = line;
    this.column = column;
    this.sourceLine = sourceLine;
  }
}

// Backwards-compatible export name for the old EasyJS source tree.
export const EasyJSError = SimpliJSError;

function distance(a, b) {
  a = String(a).toLowerCase();
  b = String(b).toLowerCase();
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    let previous = row[0];
    row[0] = i;
    for (let j = 1; j <= b.length; j += 1) {
      const current = row[j];
      row[j] = Math.min(
        row[j] + 1,
        row[j - 1] + 1,
        previous + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
      previous = current;
    }
  }
  return row[b.length];
}

export function commandSuggestion(text) {
  const first = String(text || '').trim().match(/^([A-Za-z_$][\w$]*)/);
  if (!first) return null;
  const word = first[1];
  if (COMMAND_WORDS.includes(word)) return null;
  const candidates = COMMAND_WORDS
    .map(candidate => ({ candidate, score: distance(word, candidate) }))
    .sort((a, b) => a.score - b.score);
  const best = candidates[0];
  const threshold = Math.min(3, Math.max(1, Math.ceil(Math.min(word.length, best.candidate.length) / 2)));
  return best && best.score <= threshold ? best.candidate : null;
}

export function syntaxError(message, lineInfo, suggestion = null) {
  const line = lineInfo?.line ?? null;
  const text = lineInfo?.text ?? null;
  let full = message;
  const suggestionText = suggestion || commandSuggestion(text);
  if (suggestionText) full += `\nDid you mean \'${suggestionText}\'?`;
  full += '\nTip: SimpliJS uses short, plain-English commands. Check the spelling and compare the line with the documentation.';
  return new SimpliJSError(full, line, lineInfo?.column ?? null, text);
}
