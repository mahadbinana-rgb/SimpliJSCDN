import { syntaxError, commandSuggestion } from './errors.js';
import { indentOf, isBlank, stripTrailingWhitespace, splitTopLevelCommas, normalizeExpression } from './utils.js';

const EVENT_MAP = {
  'clicked': 'click',
  'double clicked': 'dblclick',
  'changes': 'change',
  'receives input': 'input',
  'is focused': 'focus',
  'loses focus': 'blur',
  'mouse enters': 'mouseenter',
  'mouse leaves': 'mouseleave',
  'page loads': 'load',
  'document ready': 'DOMContentLoaded',
  'window resized': 'resize',
  'key pressed': 'keydown'
};

export function parse(source) {
  const rawLines = source.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let lines = rawLines.map((text, i) => ({
    text,
    line: i + 1,
    indent: indentOf(text),
    blank: isBlank(text)
  }));

  while (lines.length && lines[0].blank) lines.shift();
  stripTrailingWhitespace(lines);

  const { statements } = parseBlock(lines, 0, lines.length ? lines[0].indent : 0);
  return { type: 'Program', body: statements };
}

function parseBlock(lines, start, baseIndent) {
  const statements = [];
  let i = start;

  while (i < lines.length) {
    const item = lines[i];
    if (item.blank) { i += 1; continue; }
    if (item.indent < baseIndent) break;
    if (item.indent > baseIndent) {
      throw syntaxError('Unexpected indentation.', item);
    }

    const content = item.text.slice(item.indent).trim();
    const lineInfo = item;

    if (content === 'otherwise:' || content.startsWith('otherwise if ')) break;

    if (content === 'javascript:') {
      const { node, next } = parseJavascriptBlock(lines, i + 1, baseIndent, lineInfo);
      statements.push(node);
      i = next;
      continue;
    }

    // Allow multiline JavaScript-style array/object literals after `set`.
    const collection = parseMultilineCollectionSet(lines, i, baseIndent);
    if (collection) {
      statements.push(collection.node);
      i = collection.next;
      continue;
    }

    // Try ordinary SimpliJS commands before structured parsing.
    // This lets commands such as `create element "div" called note` work
    // without being mistaken for an object-definition block.
    const easy = parseSimpleStatement(content, lineInfo);
    if (easy) {
      statements.push(easy);
      i += 1;
      continue;
    }

    if (/^(if|repeat|while|for every|function|add function|when|create|after|every)\b/.test(content)) {
      const result = parseStructured(lines, i, baseIndent);
      statements.push(result.node);
      i = result.next;
      continue;
    }

    if (/^get data from\s+/i.test(content)) {
      statements.push(parseFetch(content, lineInfo));
      i += 1;
      continue;
    }

    if (/^post to\s+/i.test(content)) {
      const result = parsePost(lines, i, baseIndent);
      statements.push(result.node);
      i = result.next;
      continue;
    }

    if (/^add html to\s+/i.test(content)) {
      const result = parseHtmlTemplate(lines, i, baseIndent, lineInfo);
      statements.push(result.node);
      i = result.next;
      continue;
    }

    // Preserve JavaScript, but catch likely SimpliJS command typos with a friendly suggestion.
    const firstWord = content.match(/^([A-Za-z_$][\w$]*)/)?.[1];
    const suggestion = commandSuggestion(content);
    const looksLikeSimpliJS = /^(set|show|alert|save|delete|remove|clear|change|increase|decrease|multiply|divide|if|otherwise|repeat|while|for|function|run|return|create|add|push|pop|shift|unshift|reverse|sort|use|when|find|get|post|hide|toggle|focus|blur|click|validate|prevent|reload|replace|open|wait|after|every|stop|insert|replace)\b/i.test(content);
    const commandShaped = /\s(to|from|by|of|with|on|as)\s/i.test(content) || /^[^\s]+\s+["']/.test(content);
    if (firstWord && suggestion && (looksLikeSimpliJS || commandShaped || !/[.;=(){}[\]]/.test(content))) {
      throw syntaxError(`I couldn't understand "${firstWord}" here.`, lineInfo, suggestion);
    }
    statements.push({ type: 'RawJS', code: item.text.slice(item.indent), line: lineInfo.line });
    i += 1;
  }

  return { statements, next: i };
}

function consumeIndentedBlock(lines, start, parentIndent, allowEmpty = false) {
  let first = start;
  while (first < lines.length && lines[first].blank) first += 1;
  if (first >= lines.length || lines[first].indent <= parentIndent) {
    if (allowEmpty) return { body: [], next: start };
    throw syntaxError('Expected an indented block.', lines[Math.min(first, lines.length - 1)] || lines[start - 1]);
  }
  const childIndent = lines[first].indent;
  const result = parseBlock(lines, first, childIndent);
  return { body: result.statements, next: result.next };
}

function parseStructured(lines, index, parentIndent) {
  const line = lines[index];
  const content = line.text.slice(line.indent).trim();

  if (/^if\s+/i.test(content)) {
    const condition = content.replace(/^if\s+/i, '').replace(/:\s*$/, '').trim();
    const first = consumeIndentedBlock(lines, index + 1, parentIndent);
    const branches = [{ condition, body: first.body }];
    let next = first.next;
    while (next < lines.length) {
      const candidate = lines[next];
      if (candidate.blank) { next += 1; continue; }
      if (candidate.indent !== parentIndent) break;
      const c = candidate.text.slice(candidate.indent).trim();
      if (/^otherwise if\s+/i.test(c)) {
        const cond = c.replace(/^otherwise if\s+/i, '').replace(/:\s*$/, '').trim();
        const b = consumeIndentedBlock(lines, next + 1, parentIndent);
        branches.push({ condition: cond, body: b.body });
        next = b.next;
        continue;
      }
      if (c === 'otherwise:') {
        const b = consumeIndentedBlock(lines, next + 1, parentIndent, true);
        branches.push({ condition: null, body: b.body });
        next = b.next;
      }
      break;
    }
    return { node: { type: 'If', branches }, next };
  }

  if (/^repeat\s+/i.test(content)) {
    const match = /^repeat\s+(.+?)\s+times\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: repeat 10 times:', line);
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'Repeat', count: match[1].trim(), body: result.body }, next: result.next };
  }

  if (/^while\s+/i.test(content)) {
    const match = /^while\s+(.+)\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: while condition:', line);
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'While', condition: match[1].trim(), body: result.body }, next: result.next };
  }

  if (/^for every\s+/i.test(content)) {
    const match = /^for every\s+([A-Za-z_$][\w$]*)\s+in\s+(.+)\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: for every item in items:', line);
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'ForOf', item: match[1], iterable: match[2].trim() }, next: result.next };
  }

  if (/^(after|every)\s+/i.test(content)) {
    const match = /^(after|every)\s+(.+?)\s+(second|seconds|s|millisecond|milliseconds|ms|minute|minutes|m|hour|hours|h)(?:\s+as\s+([A-Za-z_$][\w$]*))?\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: after 2 seconds: or every 1 second as timer:', line);
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: match[1].toLowerCase() === 'after' ? 'Timeout' : 'Interval', delay: match[2].trim(), unit: match[3].toLowerCase(), name: match[4] || null, body: result.body }, next: result.next };
  }

  if (/^function\s+/i.test(content)) {
    const match = /^function\s+([A-Za-z_$][\w$]*)(?:\s+with(?:\s+(.+?))?)?\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: function name: or function name with arg1, arg2:', line);
    const args = match[2] ? splitTopLevelCommas(match[2]) : [];
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'Function', name: match[1], args, body: result.body }, next: result.next };
  }

  if (/^add\s+function\s+/i.test(content)) {
    const match = /^add\s+function\s+([A-Za-z_$][\w$]*)\s+to\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)(?:\s+with\s+(.+?))?\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: add function greet to user with name:', line);
    const args = match[3] ? splitTopLevelCommas(match[3]) : [];
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'ObjectMethod', object: match[2], name: match[1], args, body: result.body }, next: result.next };
  }

  if (/^when\s+/i.test(content)) {
    const match = /^when\s+(.+?)\s+is\s+(.+?)\s*:\s*$/i.exec(content);
    if (!match) throw syntaxError('Use: when "#button" is clicked:', line);
    const selector = parseTarget(match[1].trim());
    const phrase = match[2].trim().toLowerCase();
    const event = EVENT_MAP[phrase] ?? phrase;
    const result = consumeIndentedBlock(lines, index + 1, parentIndent);
    return { node: { type: 'Event', target: selector, event, body: result.body }, next: result.next };
  }

  if (/^create\s+[A-Za-z_$][\w$]*\s*:\s*$/i.test(content)) {
    return parseObjectDefinition(lines, index, parentIndent);
  }

  throw syntaxError('Unknown structured statement.', line);
}

function parseObjectDefinition(lines, index, parentIndent) {
  const line = lines[index];
  const match = /^create\s+([A-Za-z_$][\w$]*)\s*:\s*$/i.exec(line.text.slice(line.indent).trim());
  if (!match) throw syntaxError('Use: create user:', line);
  const name = match[1];
  let i = index + 1;
  while (i < lines.length && lines[i].blank) i += 1;
  if (i >= lines.length || lines[i].indent <= parentIndent) throw syntaxError(`Expected properties or methods inside create ${name}:`, line);
  const childIndent = lines[i].indent;
  const properties = [];
  const methods = [];

  while (i < lines.length) {
    const item = lines[i];
    if (item.blank) { i += 1; continue; }
    if (item.indent === parentIndent && item.text.slice(item.indent).trim().toLowerCase() === `end ${name.toLowerCase()}`) {
      i += 1;
      return { node: { type: 'CreateObject', name, properties, methods }, next: i };
    }
    if (item.indent <= parentIndent) {
      throw syntaxError(`Expected "end ${name}".`, item);
    }
    if (item.indent !== childIndent) {
      throw syntaxError('Object properties should use one indentation level.', item);
    }
    const text = item.text.slice(item.indent).trim();
    if (/^function\s+/i.test(text)) {
      const m = /^function\s+([A-Za-z_$][\w$]*)\s*:\s*$/i.exec(text);
      const m2 = /^function\s+([A-Za-z_$][\w$]*)\s+with\s+(.+)\s*:\s*$/i.exec(text);
      if (!m && !m2) throw syntaxError('Use: function greet: or function greet with name:', item);
      const result = consumeIndentedBlock(lines, i + 1, childIndent);
      methods.push({ name: (m || m2)[1], args: m2 ? splitTopLevelCommas(m2[2]) : [], body: result.body });
      i = result.next;
      continue;
    }
    const prop = /^([A-Za-z_$][\w$-]*)\s*:\s*(.+)$/.exec(text);
    if (!prop) throw syntaxError('Object fields use: name: value', item);
    properties.push({ key: prop[1], value: prop[2].trim() });
    i += 1;
  }
  throw syntaxError(`Expected "end ${name}".`, line);
}


function advanceBlock(lines, start, parentIndent) {
  let i = start;
  while (i < lines.length) {
    if (!lines[i].blank && lines[i].indent <= parentIndent) break;
    i += 1;
  }
  return i;
}

function parseJavascriptBlock(lines, start, parentIndent, lineInfo) {
  const collected = [];
  let i = start;
  let childIndent = null;
  while (i < lines.length) {
    const item = lines[i];
    if (!item.blank && item.indent <= parentIndent) break;
    if (childIndent == null && !item.blank) childIndent = item.indent;
    if (childIndent != null) {
      collected.push(item.text.slice(Math.min(item.indent, childIndent)));
    } else {
      collected.push('');
    }
    i += 1;
  }
  if (!collected.some(v => v.trim())) throw syntaxError('javascript: needs an indented JavaScript block.', lineInfo);
  return { node: { type: 'RawJS', code: collected.join('\n'), line: lineInfo.line }, next: i };
}

function parseHtmlTemplate(lines, index, parentIndent, lineInfo) {
  const header = lines[index].text.slice(lines[index].indent).trim();
  const match = /^add html to\s+(.+?)\s*:\s*$/i.exec(header);
  if (!match) throw syntaxError('Use: add HTML to "#container":', lineInfo);
  const target = parseTarget(match[1].trim());
  let i = index + 1;
  while (i < lines.length && lines[i].blank) i += 1;
  if (i >= lines.length || lines[i].indent <= parentIndent) throw syntaxError('Expected an indented HTML template block.', lineInfo);
  const childIndent = lines[i].indent;
  const parts = [];
  while (i < lines.length) {
    const item = lines[i];
    if (!item.blank && item.indent <= parentIndent) break;
    parts.push(item.text.slice(Math.min(item.indent, childIndent)));
    i += 1;
  }
  return { node: { type: 'AddHTML', target, template: parts.join('\n') }, next: i };
}

function parseFetch(content, lineInfo) {
  const match = /^get data from\s+(.+?)(?:\s+as\s+([A-Za-z_$][\w$]*))?$/i.exec(content);
  if (!match) throw syntaxError('Use: get data from "/api/users" as users', lineInfo);
  return { type: 'FetchJSON', url: match[1].trim(), name: match[2] || '__easyjsResponse' };
}

function parsePost(lines, index, parentIndent) {
  const line = lines[index];
  const content = line.text.slice(line.indent).trim();
  const match = /^post to\s+(.+?)\s+with\s*:$/i.exec(content);
  if (!match) throw syntaxError('Use: post to "/api/login" with:', line);
  let i = index + 1;
  while (i < lines.length && lines[i].blank) i += 1;
  if (i >= lines.length || lines[i].indent <= parentIndent) throw syntaxError('Expected POST body fields.', line);
  const body = [];
  const childIndent = lines[i].indent;
  while (i < lines.length) {
    const item = lines[i];
    if (!item.blank && item.indent <= parentIndent) break;
    if (!item.blank) {
      const text = item.text.slice(Math.min(item.indent, childIndent)).trim();
      const m = /^([A-Za-z_$][\w$-]*)\s*:\s*(.+)$/.exec(text);
      if (!m) throw syntaxError('POST fields use: name: value', item);
      body.push({ key: m[1], value: m[2] });
    }
    i += 1;
  }
  while (i < lines.length && lines[i].blank) i += 1;
  let saveAs = '__easyjsResponse';
  if (i < lines.length && lines[i].indent === parentIndent) {
    const following = lines[i].text.slice(lines[i].indent).trim();
    const saveMatch = /^save response as\s+([A-Za-z_$][\w$]*)$/i.exec(following);
    if (saveMatch) { saveAs = saveMatch[1]; i += 1; }
  }
  return { node: { type: 'PostJSON', url: match[1].trim(), body, name: saveAs }, next: i };
}

function parseSimpleStatement(content, lineInfo) {
  let m;

  // Direct CRUD inside values stored in browser storage. These must come before the generic object-property rules.
  if ((m = /^set\s+property\s+(["'])(.+?)\1\s+of\s+item\s+(.+?)\s+in\s+saved\s+(["'])(.+?)\4\s+to\s+(.+)$/i.exec(content))) return { type: 'StorageArraySetProperty', property: m[2], index: m[3].trim(), key: m[5], expression: m[6].trim(), storage: 'localStorage' };
  if ((m = /^set\s+property\s+(["'])(.+?)\1\s+of\s+saved\s+(["'])(.+?)\3\s+to\s+(.+)$/i.exec(content))) return { type: 'StorageObjectSetProperty', property: m[2], key: m[4], expression: m[5].trim(), storage: 'localStorage' };
  if ((m = /^remove\s+property\s+(["'])(.+?)\1\s+from\s+saved\s+(["'])(.+?)\3$/i.exec(content))) return { type: 'StorageObjectDeleteProperty', property: m[2], key: m[4], storage: 'localStorage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+property\s+(["'])(.+?)\2\s+of\s+saved\s+(["'])(.+?)\4$/i.exec(content))) return { type: 'StorageObjectGetProperty', name: m[1], property: m[3], key: m[5], storage: 'localStorage' };
  if ((m = /^add\s+(.+?)\s+to\s+saved\s+(["'])(.+?)\2$/i.exec(content))) return { type: 'StorageArrayAdd', expression: m[1].trim(), key: m[3], storage: /for\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^remove\s+item\s+(.+?)\s+from\s+saved\s+(["'])(.+?)\2$/i.exec(content))) return { type: 'StorageArrayRemoveAt', index: m[1].trim(), key: m[3], storage: /for\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^set\s+item\s+(.+?)\s+in\s+saved\s+(["'])(.+?)\2\s+to\s+(.+)$/i.exec(content))) return { type: 'StorageArraySetItem', index: m[1].trim(), key: m[3], expression: m[4].trim(), storage: /for\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };

  // Object / value helpers.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+run\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s+with(?:\s+(.+))?$/i.exec(content))) {
    return { type: 'RunExpression', name: m[1], callee: m[2], args: m[3] ? splitTopLevelCommas(m[3]) : [] };
  }
  if ((m = /^run\s+([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s+with(?:\s+(.+))?$/i.exec(content))) return { type: 'Run', name: m[1], args: m[2] ? splitTopLevelCommas(m[2]) : [] };
  if ((m = /^return\s+(.+)$/i.exec(content))) return { type: 'Return', expression: m[1].trim() };
  if ((m = /^return$/i.exec(content))) return { type: 'Return', expression: '' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?keys\s+of\s+(.+)$/i.exec(content))) return { type: 'ObjectKeys', name: m[1], object: m[2].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?values\s+of\s+(.+)$/i.exec(content))) return { type: 'ObjectValues', name: m[1], object: m[2].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?entries\s+of\s+(.+)$/i.exec(content))) return { type: 'ObjectEntries', name: m[1], object: m[2].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?(?:property|field)\s+(["'].*?["'])\s+of\s+(.+)$/i.exec(content))) return { type: 'ObjectGetProp', name: m[1], object: m[3].trim(), property: unquote(m[2]) };
  if ((m = /^set\s+(.+?)\s+property\s+(["'].*?["'])\s+to\s+(.+)$/i.exec(content))) return { type: 'ObjectSetProp', object: m[1].trim(), property: unquote(m[2]), expression: m[3].trim() };
  if ((m = /^set\s+property\s+(["'].*?["'])\s+of\s+item\s+(.+?)\s+in\s+([A-Za-z_$][\w$]*)\s+to\s+(.+)$/i.exec(content))) return { type: 'ObjectSetProp', object: `${m[3]}[Number(${m[2].trim()}) - 1]`, property: unquote(m[1]), expression: m[4].trim() };
  if ((m = /^set\s+item\s+(.+?)\s+in\s+([A-Za-z_$][\w$]*)\s+property\s+(["'].*?["'])\s+to\s+(.+)$/i.exec(content))) return { type: 'ObjectSetProp', object: `${m[2]}[Number(${m[1].trim()}) - 1]`, property: unquote(m[3]), expression: m[4].trim() };
  if ((m = /^remove\s+property\s+(["'].*?["'])\s+from\s+(.+)$/i.exec(content))) return { type: 'ObjectDeleteProp', object: m[2].trim(), property: unquote(m[1]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(.+?)\s+has\s+property\s+(["'].*?["'])$/i.exec(content))) return { type: 'ObjectHasProp', name: m[1], object: m[2].trim(), property: unquote(m[3]) };

  // Array access and built-in method aliases.
  if ((m = /^set\s+(.+?)\s+to\s+(.+?)\s+in\s+([A-Za-z_$][\w$]*)$/i.exec(content)) && /^item\s+/i.test(m[1])) {
    return { type: 'ArraySetItem', array: m[3], index: m[1].replace(/^item\s+/i, '').trim(), expression: m[2].trim() };
  }
  if ((m = /^replace\s+item\s+(.+?)\s+in\s+([A-Za-z_$][\w$]*)\s+with\s+(.+)$/i.exec(content))) return { type: 'ArraySetItem', array: m[2], index: m[1].trim(), expression: m[3].trim() };
  if ((m = /^insert\s+(.+?)\s+at\s+(.+?)\s+in\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'ArrayInsert', array: m[3], index: m[2].trim(), expression: m[1].trim() };
  if ((m = /^remove\s+item\s+(.+?)\s+from\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'ArrayRemoveAt', array: m[2], index: m[1].trim() };
  if ((m = /^clear\s+array\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'ArrayClear', array: m[1] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+item\s+(.+?)\s+from\s+(.+)$/i.exec(content))) return { type: 'ArrayGet', name: m[1], index: m[2].trim(), array: m[3].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+length\s+of\s+(.+)$/i.exec(content))) return { type: 'Length', name: m[1], array: m[2].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(splice|slice|join|includes|index\s+of|at)\s+(.+?)\s+with\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: m[2].toLowerCase(), target: m[3].trim(), args: splitTopLevelCommas(m[4]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(reverse|sort|pop|shift)\s+(?:of\s+|from\s+)?(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: m[2].toLowerCase(), target: m[3].trim(), args: [] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:join)\s+(.+?)\s+with\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'join', target: m[2].trim(), args: [m[3].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:a\s+)?slice\s+of\s+(.+?)\s+from\s+(.+?)\s+to\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'slice', target: m[2].trim(), args: [m[3].trim(), m[4].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+splice\s+(.+?)\s+starting\s+at\s+(.+?)\s+removing\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'splice', target: m[2].trim(), args: [m[3].trim(), m[4].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:item\s+)?at\s+(.+?)\s+in\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'at', target: m[3].trim(), args: [m[2].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(.+?)\s+(?:includes|contains)\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'includes', target: m[2].trim(), args: [m[3].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:index|position)\s+of\s+(.+?)\s+in\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'indexOf', target: m[3].trim(), args: [m[2].trim()] };
  if ((m = /^(?:add|push)\s+(.+)\s+to\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'ArrayAdd', expression: m[1].trim(), name: m[2].trim() };
  if ((m = /^unshift\s+(.+)\s+to\s+(.+)$/i.exec(content))) return { type: 'ArrayDiscardMethod', method: 'unshift', target: m[2].trim(), args: [m[1].trim()] };
  if ((m = /^pop\s+from\s+(.+)$/i.exec(content))) return { type: 'ArrayDiscardMethod', method: 'pop', target: m[1].trim() };
  if ((m = /^shift\s+from\s+(.+)$/i.exec(content))) return { type: 'ArrayDiscardMethod', method: 'shift', target: m[1].trim() };
  if ((m = /^reverse\s+(.+)$/i.exec(content))) return { type: 'ArrayDiscardMethod', method: 'reverse', target: m[1].trim() };
  if ((m = /^sort\s+(.+)$/i.exec(content))) return { type: 'ArrayDiscardMethod', method: 'sort', target: m[1].trim() };
  // Generic English method bridge: every JavaScript instance method remains reachable.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+use\s+([\"'])(.+?)\2\s+on\s+(.+?)(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'MethodCall', name: m[1], method: m[3], target: m[4].trim(), args: m[5] ? splitTopLevelCommas(m[5]) : [] };
  if ((m = /^use\s+([\"'])(.+?)\1\s+on\s+(.+?)(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'MethodDiscard', method: m[2], target: m[3].trim(), args: m[4] ? splitTopLevelCommas(m[4]) : [] };

  // Simplified higher-order array methods. The callback keeps JavaScript's expression power.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+concat\s+(.+?)\s+with\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'concat', target: m[2].trim(), args: [m[3].trim()] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:a\s+)?copy\s+of\s+(.+)$/i.exec(content))) return { type: 'ArrayMethod', name: m[1], method: 'slice', target: m[2].trim(), args: [] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(map|filter|find|find\s+index|every|some)\s+(.+?)\s+using\s+([A-Za-z_$][\w$]*)\s*=>\s*(.+)$/i.exec(content))) return { type: 'ArrayCallback', name: m[1], method: m[2].toLowerCase(), target: m[3].trim(), parameter: m[4], expression: m[5].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+reduce\s+(.+?)\s+using\s+([A-Za-z_$][\w$]*)\s*,\s*([A-Za-z_$][\w$]*)\s*=>\s*(.+?)\s+starting\s+at\s+(.+)$/i.exec(content))) return { type: 'ArrayReduce', name: m[1], target: m[2].trim(), accumulator: m[3], parameter: m[4], expression: m[5].trim(), initial: m[6].trim() };

  // Generic static helpers for the complete native Object/Array APIs.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+use\s+object\s+(["'])(.+?)\2(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'StaticMethodCall', name: m[1], object: 'Object', method: m[3], args: m[4] ? splitTopLevelCommas(m[4]) : [] };
  if ((m = /^use\s+object\s+(["'])(.+?)\1(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'StaticMethodDiscard', object: 'Object', method: m[2], args: m[3] ? splitTopLevelCommas(m[3]) : [] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+use\s+array\s+(["'])(.+?)\2(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'StaticMethodCall', name: m[1], object: 'Array', method: m[3], args: m[4] ? splitTopLevelCommas(m[4]) : [] };
  if ((m = /^use\s+array\s+(["'])(.+?)\1(?:\s+with\s+(.+))?$/i.exec(content))) return { type: 'StaticMethodDiscard', object: 'Array', method: m[2], args: m[3] ? splitTopLevelCommas(m[3]) : [] };

  // Object static helpers.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+object\s+(keys|values|entries)\s+of\s+(.+)$/i.exec(content))) return { type: 'ObjectStatic', name: m[1], method: m[2].toLowerCase(), object: m[3].trim() };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+object\s+(assign|is)\s+(.+)$/i.exec(content))) return { type: 'ObjectStaticArgs', name: m[1], method: m[2].toLowerCase(), args: splitTopLevelCommas(m[3]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+object\s+from\s+entries\s+(.+)$/i.exec(content))) return { type: 'ObjectStaticArgs', name: m[1], method: 'fromEntries', args: [m[2].trim()] };

  // DOM getters.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?text(?:\s+content)?\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'textContent' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?inner\s+text\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'innerText' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?(?:html|inner\s+html)\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'innerHTML' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?value\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'value' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?attribute\s+(["'].*?["'])\s+of\s+(.+)$/i.exec(content))) return { type: 'GetAttribute', name: m[1], target: parseTarget(m[3]), attribute: unquote(m[2]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+children\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetChildren', name: m[1], target: parseTarget(m[2]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(first|last)\s+child\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetChild', name: m[1], which: m[2].toLowerCase(), target: parseTarget(m[3]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(parent|next sibling|previous sibling)\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetRelation', name: m[1], relation: m[2].toLowerCase(), target: parseTarget(m[3]) };

  // DOM setters and properties.
  if ((m = /^set\s+(.+?)\s+(inner\s+text|innerText|text|textContent)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMSetText', target: parseTarget(m[1]), expression: m[3].trim(), property: /inner\s*text|innerText/i.test(m[2]) ? 'innerText' : 'textContent' };
  if ((m = /^set\s+(.+?)\s+(inner\s+html|innerHTML|html)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMSetHTML', target: parseTarget(m[1]), expression: m[3].trim() };
  if ((m = /^set\s+(.+?)\s+(value|checked|disabled|id|class|className|href|src|title|name|type|placeholder|outerHTML)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMSetProp', target: parseTarget(m[1]), property: m[2] === 'class' ? 'className' : m[2], expression: m[3].trim() };
  if ((m = /^set\s+(.+?)\s+property\s+(["'].*?["'])\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMSetProp', target: parseTarget(m[1]), property: unquote(m[2]), expression: m[3].trim() };
  if ((m = /^set\s+(.+?)\s+style\.([\w-]+)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMStyle', target: parseTarget(m[1]), property: m[2], expression: m[3].trim() };
  if ((m = /^set\s+(.+?)\s+css\s+(["']--[^"']+["'])\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMCSSVar', target: parseTarget(m[1]), property: unquote(m[2]), expression: m[3].trim() };
  if ((m = /^set\s+css variable\s+(["']--[^"']+["'])\s+on\s+(.+?)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMCSSVar', target: parseTarget(m[2]), property: unquote(m[1]), expression: m[3].trim() };
  if ((m = /^set\s+(.+?)\s+attribute\s+(["'].*?["'])\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMSetAttribute', target: parseTarget(m[1]), attribute: unquote(m[2]), expression: m[3].trim() };
  if ((m = /^remove\s+attribute\s+(["'].*?["'])\s+from\s+(.+)$/i.exec(content))) return { type: 'DOMRemoveAttribute', target: parseTarget(m[2]), attribute: unquote(m[1]) };
  if ((m = /^set\s+(.+?)\s+(.+?)\s+to\s+(.+)$/i.exec(content))) {
    const css = naturalCssProperty(m[2]);
    if (css) return { type: 'DOMStyle', target: parseTarget(m[1]), property: css, expression: m[3].trim() };
  }

  // Element lookup / creation.
  if ((m = /^create\s+element\s+(["'].*?["'])\s+called\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'CreateElement', tag: unquote(m[1]), name: m[2] };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+element\s+(.+)$/i.exec(content))) return { type: 'GetElement', name: m[1], target: parseTarget(m[2]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+elements\s+(.+)$/i.exec(content))) return { type: 'GetElements', name: m[1], target: parseTarget(m[2]) };
  if ((m = /^find\s+all\s+elements\s+(.+?)(?:\s+inside\s+(.+))?$/i.exec(content))) return { type: 'FindElements', selector: parseTarget(m[1]), inside: m[2] ? parseTarget(m[2]) : null };
  if ((m = /^find\s+element\s+(.+?)(?:\s+inside\s+(.+))?$/i.exec(content))) return { type: 'FindElement', selector: parseTarget(m[1]), inside: m[2] ? parseTarget(m[2]) : null };

  if ((m = /^show\s+(.+)$/i.exec(content))) {
    const value = m[1].trim();
    const selectorLiteral = ((value.startsWith('\"') && value.endsWith('\"')) || (value.startsWith("'") && value.endsWith("'"))) && /^(?:\"|')[.#][^\"']*(?:\"|')$/.test(value);
    if (selectorLiteral) return { type: 'DOMVisibility', action: 'show', target: parseTarget(value) };
    return { type: 'Show', expression: value };
  }
  if ((m = /^alert\s+(.+)$/i.exec(content))) return { type: 'Alert', expression: m[1].trim() };

  // Local/session storage: browser CRUD in English. Values may be objects or arrays.
  // Local/session storage: browser CRUD in English.
  if ((m = /^save\s+(.+?)\s+as\s+(["'].*?["'])(?:\s+for\s+this\s+session)?$/i.exec(content))) return { type: 'Save', expression: m[1].trim(), key: unquote(m[2]), storage: /for\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+saved\s+(["'].*?["'])(?:\s+from\s+this\s+session)?$/i.exec(content))) return { type: 'Load', name: m[1], key: unquote(m[2]), storage: /from\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+saved\s+keys(?:\s+from\s+this\s+session)?$/i.exec(content))) return { type: 'StorageKeys', name: m[1], storage: /from\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+saved\s+data\s+count(?:\s+from\s+this\s+session)?$/i.exec(content))) return { type: 'StorageLength', name: m[1], storage: /from\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^if\s+saved\s+(["'].*?["'])\s+exists$/i.exec(content))) return null;
  if ((m = /^(?:delete|remove)\s+saved\s+(["'].*?["'])(?:\s+from\s+this\s+session)?$/i.exec(content))) return { type: 'DeleteSaved', key: unquote(m[1]), storage: /from\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if (/^clear\s+(?:saved|local)\s+data$/i.test(content)) return { type: 'ClearSaved', storage: 'localStorage' };
  if (/^clear\s+session\s+data$/i.test(content)) return { type: 'ClearSaved', storage: 'sessionStorage' };
  if ((m = /^set\s+saved\s+(\"|')(.+?)\1\s+to\s+(.+?)(?:\s+for\s+this\s+session)?$/i.exec(content))) return { type: 'Save', expression: m[3].trim(), key: m[2], storage: /for\s+this\s+session$/i.test(content) ? 'sessionStorage' : 'localStorage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+saved\s+(["'].*?["'])\s+raw$/i.exec(content))) return { type: 'LoadRaw', name: m[1], key: unquote(m[2]), storage: 'localStorage' };
  // Friendly browser input helpers.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?(?:input\s+)?value\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'value' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+checked\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'checked' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?type\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'type' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?name\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'name' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?id\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'id' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?class\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'className' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:the\s+)?(?:valid|validity)\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMValidity', name: m[1], target: parseTarget(m[2]) };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(?:validation\s+message|error\s+message)\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMGetProp', name: m[1], target: parseTarget(m[2]), property: 'validationMessage' };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+form\s+(?:data|fields)\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMFormData', name: m[1], target: parseTarget(m[2]) };

  // Prompt helpers.
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+ask\((.*)\)$/i.exec(content))) return { type: 'Set', name: m[1], expression: `ask(${m[2]})` };
  if ((m = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+askYesNo\((.*)\)$/i.exec(content))) return { type: 'Set', name: m[1], expression: `askYesNo(${m[2]})` };

  // Math and date/time helpers are functions so they remain valid inside any expression.
  const helperNoArgs = ['random', 'pi', 'now', 'today', 'timeNow', 'currentYear'];
  for (const helper of helperNoArgs) {
    const re = new RegExp(`^set\\s+([A-Za-z_$][\\w$]*)\\s+to\\s+${helper}\\(\\s*\\)$`, 'i');
    const mm = re.exec(content);
    if (mm) return { type: 'Set', name: mm[1], expression: `${helper}()` };
  }
  for (const helper of ['round', 'roundUp', 'roundDown', 'absolute', 'squareRoot', 'randomBetween', 'power', 'min', 'max']) {
    const re = new RegExp(`^set\\s+([A-Za-z_$][\\w$]*)\\s+to\\s+${helper}\\((.+)\\)$`, 'i');
    const mm = re.exec(content);
    if (mm) return { type: 'Set', name: mm[1], expression: `${helper}(${mm[2]})` };
  }
  for (const helper of ['dateIn', 'timeIn', 'dateTimeIn']) {
    const re = new RegExp(`^set\\s+([A-Za-z_$][\\w$]*)\\s+to\\s+${helper}\\((.+)\\)$`, 'i');
    const mm = re.exec(content);
    if (mm) return { type: 'Set', name: mm[1], expression: `${helper}(${mm[2]})` };
  }

  if ((m = /^set\s+(.+?)\s+to\s+(.+)$/i.exec(content))) {
    // Plain variable assignment first; DOM/object property assignment is handled by parseSetTarget.
    if (/^[A-Za-z_$][\w$]*$/.test(m[1].trim())) return { type: 'Set', name: m[1], expression: normalizeExpression(m[2]) };
    return parseSetTarget(m[1], m[2], lineInfo);
  }

  // Timer cancellation must be checked before the generic `clear` DOM command.
  if ((m = /^stop\s+(?:timer|timers)\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'StopTimer', name: m[1] };
  if ((m = /^clear\s+(?:timer|interval|timeout)\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'StopTimer', name: m[1] };

  // DOM visibility, classes, children.
  if ((m = /^show\s+(.+)$/i.exec(content))) return { type: 'Show', expression: m[1].trim() };
  if ((m = /^alert\s+(.+)$/i.exec(content))) return { type: 'Alert', expression: m[1].trim() };
  if ((m = /^(hide|toggle)\s+(.+)$/i.exec(content))) return { type: 'DOMVisibility', action: m[1].toLowerCase(), target: parseTarget(m[2]) };
  if ((m = /^(add|remove|toggle)\s+class\s+(.+?)\s+(?:to|from|on)\s+(.+)$/i.exec(content))) return { type: 'DOMClass', action: m[1].toLowerCase(), className: m[2].trim(), target: parseTarget(m[3]) };
  if ((m = /^remove\s+(.+)$/i.exec(content))) return { type: 'DOMRemove', target: parseTarget(m[1]) };
  if ((m = /^clear(?:\s+children)?\s+of\s+(.+)$/i.exec(content))) return { type: 'DOMClear', target: parseTarget(m[1]) };
  if ((m = /^clear\s+(.+)$/i.exec(content))) return { type: 'DOMClear', target: parseTarget(m[1]) };
  if ((m = /^add\s+child\s+(.+?)\s+to\s+(.+)$/i.exec(content))) return { type: 'DOMAppend', child: parseTarget(m[1]), parent: parseTarget(m[2]) };
  if ((m = /^remove\s+child\s+(.+?)\s+from\s+(.+)$/i.exec(content))) return { type: 'DOMRemoveChild', child: parseTarget(m[1]), parent: parseTarget(m[2]) };
  if ((m = /^set\s+(.+?)\s+on\s+(.+)$/i.exec(content))) return null;

  // DOM append shortcut: `add note to "#notes"`.
  if ((m = /^add\s+(.+?)\s+to\s+(["'].*?["'])$/i.exec(content))) return { type: 'DOMAppend', child: parseTarget(m[1]), parent: parseTarget(m[2]) };

  // Arrays: mutate / simple CRUD.
  if ((m = /^remove\s+(.+?)\s+from\s+([A-Za-z_$][\w$]*)$/i.exec(content))) return { type: 'ArrayRemove', expression: m[1].trim(), name: m[2] };
  if ((m = /^(increase|decrease|multiply|divide)\s+(.+?)\s+by\s+(.+)$/i.exec(content))) return { type: 'Change', operation: m[1].toLowerCase(), target: parseTarget(m[2]), value: normalizeExpression(m[3]) };
  if ((m = /^change\s+(.+?)\s+by\s+(.+)$/i.exec(content))) return { type: 'Change', operation: 'increase', target: parseTarget(m[1]), value: normalizeExpression(m[2]) };
  // Browser navigation.
  if (/^reload page$/i.test(content)) return { type: 'RawJS', code: 'location.reload();' };
  if (/^go back$/i.test(content)) return { type: 'RawJS', code: 'history.back();' };
  if (/^go forward$/i.test(content)) return { type: 'RawJS', code: 'history.forward();' };
  if ((m = /^go to\s+(.+)$/i.exec(content))) return { type: 'RawJS', code: `location.href = ${m[1].trim()};` };
  if ((m = /^replace page with\s+(.+)$/i.exec(content))) return { type: 'RawJS', code: `location.replace(${m[1].trim()});` };
  if ((m = /^open\s+(.+?)(?:\s+in new tab)?$/i.exec(content))) {
    const newTab = /\s+in new tab$/i.test(content);
    return { type: 'RawJS', code: `window.open(${m[1].trim()}, ${newTab ? '"_blank"' : '"_self"'});` };
  }
  if ((m = /^validate\s+(.+)$/i.exec(content))) return { type: 'DOMValidate', target: parseTarget(m[1]) };
  if ((m = /^focus\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'focus', target: parseTarget(m[1]) };
  if ((m = /^blur\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'blur', target: parseTarget(m[1]) };
  if ((m = /^click\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'click', target: parseTarget(m[1]) };
  if ((m = /^select\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'select', target: parseTarget(m[1]) };
  if (/^prevent default$/i.test(content)) return { type: 'PreventDefault' };
  if ((m = /^submit\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'requestSubmit', target: parseTarget(m[1]) };
  if ((m = /^reset\s+(.+)$/i.exec(content))) return { type: 'DOMAction', action: 'reset', target: parseTarget(m[1]) };

  // Timers and async waiting.
  if ((m = /^wait\s*\((.+?)\s+(second|seconds|s|millisecond|milliseconds|ms|minute|minutes|m|hour|hours|h)\)\s*$/i.exec(content))) {
    const seconds = { ms: 0.001, milliseconds: 0.001, s: 1, second: 1, seconds: 1, m: 60, minute: 60, minutes: 60, h: 3600, hour: 3600, hours: 3600 }[m[2].toLowerCase()] || 1;
    return { type: 'Wait', expression: `(${m[1].trim()} * ${seconds})` };
  }
  if ((m = /^wait\s*\((.*)\)\s*$/i.exec(content))) return { type: 'Wait', expression: m[1].trim() };
  if ((m = /^wait\s+(.+?)\s+(second|seconds|s|millisecond|milliseconds|ms|minute|minutes|m|hour|hours|h)$/i.exec(content))) {
    const seconds = { ms: 0.001, milliseconds: 0.001, s: 1, second: 1, seconds: 1, m: 60, minute: 60, minutes: 60, h: 3600, hour: 3600, hours: 3600 }[m[2].toLowerCase()] || 1;
    return { type: 'Wait', expression: `(${m[1].trim()} * ${seconds})` };
  }

  return null;
}

function parseMultilineCollectionSet(lines, index, baseIndent) {
  const first = lines[index];
  const content = first.text.slice(first.indent).trim();
  const match = /^set\s+([A-Za-z_$][\w$]*)\s+to\s+(.+)$/i.exec(content);
  if (!match) return null;
  const initial = match[2].trim();
  if (!initial.startsWith('[') && !initial.startsWith('{')) return null;
  let combined = initial;
  let i = index + 1;
  let depth = bracketBalance(combined);
  if (depth <= 0) return null;
  while (i < lines.length) {
    const item = lines[i];
    combined += `\n${item.text.trim()}`;
    depth += bracketBalance(item.text.trim());
    i += 1;
    if (depth <= 0) break;
  }
  if (depth > 0) throw syntaxError('This array or object is missing a closing bracket.', first);
  return { node: { type: 'Set', name: match[1], expression: normalizeExpression(combined) }, next: i };
}

function bracketBalance(text) {
  let depth = 0;
  let quote = null;
  let escaped = false;
  for (const c of text) {
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (c === '\\') { escaped = true; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'" || c === '`') { quote = c; continue; }
    if (c === '[' || c === '{' || c === '(') depth += 1;
    else if (c === ']' || c === '}' || c === ')') depth -= 1;
  }
  return depth;
}

function parseSetTarget(targetText, expression, lineInfo) {
  const target = targetText.trim();
  if (/^(.+?)\s+attribute\s+(["'].*?["'])$/i.test(target)) {
    const m = /^(.+?)\s+attribute\s+(["'].*?["'])$/i.exec(target);
    return { type: 'DOMSetAttribute', target: parseTarget(m[1]), attribute: unquote(m[2]), expression: expression.trim() };
  }
  if (/^id\s+to\s+attribute\s+(["'].*?["'])\s+of\s+(.+)$/i.test(target)) {
    const m = /^id\s+to\s+attribute\s+(["'].*?["'])\s+of\s+(.+)$/i.exec(target);
    return { type: 'GetAttribute', name: '___anonymous', target: parseTarget(m[2]), attribute: unquote(m[1]) };
  }
  return { type: 'RawSetTarget', target: parseTarget(target), expression: expression.trim() };
}

function parseTarget(text) {
  const value = text.trim();
  if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
    return { type: 'selector', value: unquote(value) };
  }
  return { type: 'expression', value };
}

function unquote(value) {
  try { return JSON.parse(value.startsWith("'") ? '"' + value.slice(1, -1).replace(/"/g, '\\"') + '"' : value); }
  catch { return value.slice(1, -1); }
}

function naturalCssProperty(text) {
  const normalized = text.trim().toLowerCase().replace(/\s+/g, ' ');
  const map = {
    'background color': 'backgroundColor', 'background image': 'backgroundImage',
    'font size': 'fontSize', 'font weight': 'fontWeight', 'font family': 'fontFamily',
    'margin top': 'marginTop', 'margin right': 'marginRight', 'margin bottom': 'marginBottom', 'margin left': 'marginLeft',
    'padding top': 'paddingTop', 'padding right': 'paddingRight', 'padding bottom': 'paddingBottom', 'padding left': 'paddingLeft',
    'border radius': 'borderRadius', 'border width': 'borderWidth', 'border color': 'borderColor',
    'line height': 'lineHeight', 'text align': 'textAlign', 'z index': 'zIndex',
    'justify content': 'justifyContent', 'align items': 'alignItems', 'flex direction': 'flexDirection',
    'box shadow': 'boxShadow', 'letter spacing': 'letterSpacing', 'opacity': 'opacity', 'width': 'width', 'height': 'height',
    'color': 'color', 'display': 'display', 'position': 'position', 'top': 'top', 'right': 'right', 'bottom': 'bottom', 'left': 'left',
    'transform': 'transform', 'overflow': 'overflow', 'cursor': 'cursor'
  };
  return map[normalized] || null;
}
