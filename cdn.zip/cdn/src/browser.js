import { compile, inspect } from './compiler.js';

const VERSION = '0.4.0';

const COUNTRY_TIMEZONES = {
  pakistan: 'Asia/Karachi', pk: 'Asia/Karachi', karachi: 'Asia/Karachi',
  japan: 'Asia/Tokyo', jp: 'Asia/Tokyo', tokyo: 'Asia/Tokyo',
  'south korea': 'Asia/Seoul', korea: 'Asia/Seoul', kr: 'Asia/Seoul', seoul: 'Asia/Seoul',
  china: 'Asia/Shanghai', cn: 'Asia/Shanghai', shanghai: 'Asia/Shanghai',
  india: 'Asia/Kolkata', in: 'Asia/Kolkata', mumbai: 'Asia/Kolkata', delhi: 'Asia/Kolkata',
  bangladesh: 'Asia/Dhaka', bd: 'Asia/Dhaka', dhaka: 'Asia/Dhaka',
  nepal: 'Asia/Kathmandu', np: 'Asia/Kathmandu', kathmandu: 'Asia/Kathmandu',
  'united arab emirates': 'Asia/Dubai', uae: 'Asia/Dubai', ae: 'Asia/Dubai', dubai: 'Asia/Dubai',
  'saudi arabia': 'Asia/Riyadh', saudi: 'Asia/Riyadh', sa: 'Asia/Riyadh', riyadh: 'Asia/Riyadh',
  qatar: 'Asia/Qatar', qa: 'Asia/Qatar', doha: 'Asia/Qatar',
  oman: 'Asia/Muscat', om: 'Asia/Muscat', muscat: 'Asia/Muscat',
  turkey: 'Europe/Istanbul', tr: 'Europe/Istanbul', istanbul: 'Europe/Istanbul',
  'united kingdom': 'Europe/London', uk: 'Europe/London', britain: 'Europe/London', london: 'Europe/London',
  ireland: 'Europe/Dublin', ie: 'Europe/Dublin', dublin: 'Europe/Dublin',
  france: 'Europe/Paris', fr: 'Europe/Paris', paris: 'Europe/Paris',
  germany: 'Europe/Berlin', de: 'Europe/Berlin', berlin: 'Europe/Berlin',
  italy: 'Europe/Rome', it: 'Europe/Rome', rome: 'Europe/Rome',
  spain: 'Europe/Madrid', es: 'Europe/Madrid', madrid: 'Europe/Madrid',
  portugal: 'Europe/Lisbon', pt: 'Europe/Lisbon', lisbon: 'Europe/Lisbon',
  netherlands: 'Europe/Amsterdam', holland: 'Europe/Amsterdam', nl: 'Europe/Amsterdam', amsterdam: 'Europe/Amsterdam',
  switzerland: 'Europe/Zurich', ch: 'Europe/Zurich', zurich: 'Europe/Zurich',
  austria: 'Europe/Vienna', at: 'Europe/Vienna', vienna: 'Europe/Vienna',
  sweden: 'Europe/Stockholm', se: 'Europe/Stockholm', stockholm: 'Europe/Stockholm',
  norway: 'Europe/Oslo', no: 'Europe/Oslo', oslo: 'Europe/Oslo',
  denmark: 'Europe/Copenhagen', dk: 'Europe/Copenhagen', copenhagen: 'Europe/Copenhagen',
  finland: 'Europe/Helsinki', fi: 'Europe/Helsinki', helsinki: 'Europe/Helsinki',
  poland: 'Europe/Warsaw', pl: 'Europe/Warsaw', warsaw: 'Europe/Warsaw',
  ukraine: 'Europe/Kyiv', ua: 'Europe/Kyiv', kyiv: 'Europe/Kyiv', kiev: 'Europe/Kyiv',
  russia: 'Europe/Moscow', ru: 'Europe/Moscow', moscow: 'Europe/Moscow',
  egypt: 'Africa/Cairo', eg: 'Africa/Cairo', cairo: 'Africa/Cairo',
  nigeria: 'Africa/Lagos', ng: 'Africa/Lagos', lagos: 'Africa/Lagos',
  kenya: 'Africa/Nairobi', ke: 'Africa/Nairobi', nairobi: 'Africa/Nairobi',
  'south africa': 'Africa/Johannesburg', za: 'Africa/Johannesburg', johannesburg: 'Africa/Johannesburg',
  morocco: 'Africa/Casablanca', ma: 'Africa/Casablanca', casablanca: 'Africa/Casablanca',
  ghana: 'Africa/Accra', gh: 'Africa/Accra', accra: 'Africa/Accra',
  'united states': 'America/New_York', usa: 'America/New_York', us: 'America/New_York', 'new york': 'America/New_York',
  'los angeles': 'America/Los_Angeles', california: 'America/Los_Angeles',
  'chicago': 'America/Chicago',
  'denver': 'America/Denver',
  canada: 'America/Toronto', ca: 'America/Toronto', toronto: 'America/Toronto',
  mexico: 'America/Mexico_City', mx: 'America/Mexico_City', 'mexico city': 'America/Mexico_City',
  brazil: 'America/Sao_Paulo', br: 'America/Sao_Paulo', 'sao paulo': 'America/Sao_Paulo',
  argentina: 'America/Argentina/Buenos_Aires', ar: 'America/Argentina/Buenos_Aires', 'buenos aires': 'America/Argentina/Buenos_Aires',
  chile: 'America/Santiago', cl: 'America/Santiago', santiago: 'America/Santiago',
  colombia: 'America/Bogota', co: 'America/Bogota', bogota: 'America/Bogota',
  australia: 'Australia/Sydney', au: 'Australia/Sydney', sydney: 'Australia/Sydney',
  'new zealand': 'Pacific/Auckland', nz: 'Pacific/Auckland', auckland: 'Pacific/Auckland',
  singapore: 'Asia/Singapore', sg: 'Asia/Singapore',
  malaysia: 'Asia/Kuala_Lumpur', my: 'Asia/Kuala_Lumpur', 'kuala lumpur': 'Asia/Kuala_Lumpur',
  indonesia: 'Asia/Jakarta', id: 'Asia/Jakarta', jakarta: 'Asia/Jakarta',
  thailand: 'Asia/Bangkok', th: 'Asia/Bangkok', bangkok: 'Asia/Bangkok',
  vietnam: 'Asia/Ho_Chi_Minh', vn: 'Asia/Ho_Chi_Minh', 'ho chi minh': 'Asia/Ho_Chi_Minh',
  philippines: 'Asia/Manila', ph: 'Asia/Manila', manila: 'Asia/Manila',
  israel: 'Asia/Jerusalem', il: 'Asia/Jerusalem', jerusalem: 'Asia/Jerusalem',
  greece: 'Europe/Athens', gr: 'Europe/Athens', athens: 'Europe/Athens',
  iceland: 'Atlantic/Reykjavik', is: 'Atlantic/Reykjavik', reykjavik: 'Atlantic/Reykjavik'
};

function warn(message) {
  console.warn(`[SimpliJS warning] ${message}`);
}

function resolveElement(value, quiet = false) {
  if (value == null) return null;
  if (typeof Element !== 'undefined' && value instanceof Element) return value;
  if (typeof Document !== 'undefined' && value instanceof Document) return value;
  if (typeof Window !== 'undefined' && value instanceof Window) return value;
  if (typeof value === 'string') {
    try { return document.querySelector(value); }
    catch { if (!quiet) warn(`The selector "${value}" is not valid.`); return null; }
  }
  return value;
}

function resolveElements(value, quiet = false) {
  if (value == null) return [];
  if (typeof value === 'string') {
    try { return [...document.querySelectorAll(value)]; }
    catch { if (!quiet) warn(`The selector "${value}" is not valid.`); return []; }
  }
  if (typeof Element !== 'undefined' && value instanceof Element) return [value];
  if (typeof NodeList !== 'undefined' && value instanceof NodeList) return [...value];
  if (Array.isArray(value)) return value;
  return value ? [value] : [];
}

function resolveTarget(value) {
  if (typeof value === 'string') return resolveElement(value);
  return value;
}

function getEasyJSElement(value, inside) {
  const root = resolveTarget(inside) || document;
  if (typeof value === 'string') {
    try {
      const result = root.querySelector(value);
      if (!result) {
        const friendly = value.startsWith('#') && /^[A-Za-z_][\w-]*$/.test(value.slice(1))
          ? `I couldn't find the element with id ${value.slice(1)}. Check that your HTML contains id=\"${value.slice(1)}\".`
          : `I couldn't find an element matching \"${value}\". Check that the selector matches an element in your page.`;
        warn(friendly);
      }
      return result;
    } catch {
      warn(`The selector "${value}" is not valid.`);
      return null;
    }
  }
  return resolveElement(value);
}

function getEasyJSElements(value, inside) {
  const root = resolveTarget(inside) || document;
  if (typeof value === 'string') {
    try { return [...root.querySelectorAll(value)]; }
    catch { warn(`The selector "${value}" is not valid.`); return []; }
  }
  return resolveElements(value, true);
}

function getEasyJSEventTargets(value) {
  const resolved = resolveElements(value, true);
  if (resolved.length) return resolved;
  if (value !== document && value !== window) warn(`I couldn't attach the event because no element matched the target.`);
  return [];
}
function easyJSEventTargets(value) { return getEasyJSEventTargets(value); }
function normalizeTargets(value) { return resolveElements(value, true); }

function appendEasyJS(parent, child, before = false) {
  const p = resolveElement(parent);
  if (!p) return;
  if (typeof Node !== 'undefined' && child instanceof Node) {
    if (before) p.insertBefore(child, p.firstChild); else p.appendChild(child);
  } else if (Array.isArray(child)) {
    for (const c of child) if (typeof Node !== 'undefined' && c instanceof Node) {
      if (before) p.insertBefore(c, p.firstChild); else p.appendChild(c);
    }
  }
}

function removeEasyJSChild(parent, child) {
  const p = resolveElement(parent);
  const c = resolveElement(child);
  if (p && c && c.parentNode === p) p.removeChild(c);
}

function easyJSReadStorage(storage, key) {
  const raw = storage.getItem(key);
  if (raw == null) return null;
  try { return JSON.parse(raw); } catch { return raw; }
}
function easyJSHasStorage(storage, key) { return storage.getItem(key) !== null; }
function easyJSStorageKeys(storage) {
  const keys = [];
  for (let i = 0; i < storage.length; i += 1) {
    const key = storage.key(i);
    if (key !== null) keys.push(key);
  }
  return keys;
}

function easyJSSave(storage, key, value) {
  try { storage.setItem(key, JSON.stringify(value)); }
  catch (error) { warn(`I couldn't save "${key}". ${error?.message || 'The browser storage may be full or unavailable.'}`); }
}

function easyJSUpdateStoredValue(storage, key, updater) {
  const current = easyJSReadStorage(storage, key);
  if (current === null && !easyJSHasStorage(storage, key)) {
    warn(`I couldn't update "${key}" because nothing is saved there yet.`);
    return null;
  }
  try {
    const next = updater(current);
    easyJSSave(storage, key, next);
    return next;
  } catch (error) {
    warn(`I couldn't update "${key}". ${error?.message || 'Check the saved value and try again.'}`);
    return current;
  }
}

function ask(message, defaultValue = '') { return window.prompt(String(message), String(defaultValue)); }
function askYesNo(message, defaultValue = false) {
  return window.confirm(String(message));
}

function wait(seconds) {
  const ms = Math.max(0, Number(seconds) * 1000);
  return new Promise(resolve => setTimeout(resolve, ms));
}

function random() { return Math.random(); }
function randomBetween(minimum, maximum) {
  let min = Number(minimum);
  let max = Number(maximum);
  if (!Number.isFinite(min) || !Number.isFinite(max)) return NaN;
  if (min > max) [min, max] = [max, min];
  min = Math.ceil(min);
  max = Math.floor(max);
  if (max < min) return min;
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
function round(value) { return Math.round(Number(value)); }
function roundUp(value) { return Math.ceil(Number(value)); }
function roundDown(value) { return Math.floor(Number(value)); }
function absolute(value) { return Math.abs(Number(value)); }
function power(value, exponent) { return Math.pow(Number(value), Number(exponent)); }
function squareRoot(value) { return Math.sqrt(Number(value)); }
function min(...values) { return Math.min(...values.map(Number)); }
function max(...values) { return Math.max(...values.map(Number)); }
function pi() { return Math.PI; }

function now() { return new Date(); }
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function timeNow() {
  return new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date());
}
function currentYear() { return new Date().getFullYear(); }

function resolveTimeZone(countryOrZone) {
  const raw = String(countryOrZone ?? '').trim();
  const key = raw.toLowerCase();
  const mapped = COUNTRY_TIMEZONES[key] || raw;
  if (!mapped) return Intl.DateTimeFormat().resolvedOptions().timeZone;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: mapped }).format();
    return mapped;
  } catch {
    warn(`I don't know the time zone "${raw}". Try a country name like "Japan" or an IANA zone like "Asia/Tokyo". Using your local time zone instead.`);
    return Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
}
function dateIn(countryOrZone) {
  return new Intl.DateTimeFormat(undefined, { timeZone: resolveTimeZone(countryOrZone), year: 'numeric', month: 'long', day: 'numeric' }).format(new Date());
}
function timeIn(countryOrZone) {
  return new Intl.DateTimeFormat(undefined, { timeZone: resolveTimeZone(countryOrZone), hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date());
}
function dateTimeIn(countryOrZone) {
  return new Intl.DateTimeFormat(undefined, { timeZone: resolveTimeZone(countryOrZone), dateStyle: 'medium', timeStyle: 'medium' }).format(new Date());
}

function easyJSIsValid(value) {
  const element = resolveElement(value, true);
  return !!(element && typeof element.checkValidity === 'function' && element.checkValidity());
}

function easyJSFormData(value) {
  const form = resolveElement(value, true);
  if (!form) return {};
  const data = {};
  try {
    const entries = new FormData(form).entries();
    for (const [key, entryValue] of entries) {
      if (Object.prototype.hasOwnProperty.call(data, key)) data[key] = Array.isArray(data[key]) ? [...data[key], entryValue] : [data[key], entryValue];
      else data[key] = entryValue;
    }
  } catch (error) { warn(`I couldn't read that form. ${error?.message || ''}`.trim()); }
  return data;
}

function execute(code, nonce) {
  const script = document.createElement('script');
  script.type = 'text/javascript';
  if (nonce) script.nonce = nonce;
  script.textContent = `const {getEasyJSElement,getEasyJSElements,easyJSEventTargets,easyJSNormalizeTargets,appendEasyJS,removeEasyJSChild,easyJSReadStorage,easyJSHasStorage,easyJSStorageKeys,easyJSSave,easyJSUpdateStoredValue,ask,askYesNo,wait,random,randomBetween,round,roundUp,roundDown,absolute,power,squareRoot,min,max,pi,now,today,timeNow,currentYear,dateIn,timeIn,dateTimeIn,easyJSIsValid,easyJSFormData}=globalThis.__simplijsRuntime;\n${code}`;
  (document.head || document.documentElement).appendChild(script);
  script.remove();
}

function findNonce() {
  const scripts = document.querySelectorAll('script[src]');
  for (const script of scripts) {
    if ((script.src || '').includes('simplijs') || (script.src || '').includes('easyjs')) return script.nonce || script.getAttribute('nonce') || '';
  }
  return '';
}

function runDocument(options = {}) {
  const blocks = [...document.querySelectorAll('simplijs, easyjs')];
  if (!blocks.length) return { blocks: 0, code: '' };

  const source = blocks.map(block => {
    if (block.matches('easyjs') && !block.matches('simplijs')) warn('<easyjs> is the old tag name. Use <simplijs> in new code.');
    block.setAttribute('data-simplijs-compiled', 'true');
    block.style.display = 'none';
    return block.innerHTML;
  }).join('\n\n');

  const code = compile(source);
  execute(code, options.nonce ?? findNonce());
  return { blocks: blocks.length, code };
}

function showError(error) {
  console.error('[SimpliJS]', error);
  const root = document.body || document.documentElement;
  if (!root) return;
  const old = document.querySelector('[data-simplijs-error]');
  old?.remove();
  const box = document.createElement('pre');
  box.setAttribute('data-simplijs-error', 'true');
  box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:12px;z-index:2147483647;max-height:45vh;overflow:auto;padding:16px 18px;border-radius:12px;background:#18120f;color:#ffe1d3;border:1px solid #5b2b22;box-shadow:0 16px 50px rgba(0,0,0,.35);font:14px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap;';
  box.textContent = `SimpliJS found a problem:\n\n${error?.message || error}`;
  root.appendChild(box);
}

function boot() {
  try { runDocument(); }
  catch (error) { showError(error); }
}

globalThis.SimpliJS = {
  version: VERSION,
  compile,
  inspect,
  run(source) {
    const code = compile(source);
    execute(code, findNonce());
    return code;
  },
  compileDocument: runDocument,
  helpers: { ask, askYesNo, wait, random, randomBetween, round, roundUp, roundDown, absolute, power, squareRoot, min, max, pi, now, today, timeNow, currentYear, dateIn, timeIn, dateTimeIn }
};
// Backwards-compatible alias for projects started under the old name.
globalThis.EasyJS = globalThis.SimpliJS;

globalThis.__simplijsRuntime = {
  getEasyJSElement,
  getEasyJSElements,
  easyJSEventTargets,
  easyJSNormalizeTargets: normalizeTargets,
  appendEasyJS,
  removeEasyJSChild,
  easyJSReadStorage,
  easyJSHasStorage,
  easyJSStorageKeys,
  easyJSSave,
  easyJSUpdateStoredValue,
  ask,
  askYesNo,
  wait,
  random,
  randomBetween,
  round,
  roundUp,
  roundDown,
  absolute,
  power,
  squareRoot,
  min,
  max,
  pi,
  now,
  today,
  timeNow,
  currentYear,
  dateIn,
  timeIn,
  dateTimeIn,
  easyJSIsValid,
  easyJSFormData
};
// Old internal name kept so generated bundles from earlier releases remain easier to inspect.
globalThis.__easyjsRuntime = globalThis.__simplijsRuntime;

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
else boot();
