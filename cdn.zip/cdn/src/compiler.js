import { parse } from './parser.js';
import { CodeGenerator } from './generator.js';

export function compile(source) {
  const ast = parse(source);
  const generator = new CodeGenerator();
  return generator.generate(ast);
}

export function inspect(source) {
  return parse(source);
}
