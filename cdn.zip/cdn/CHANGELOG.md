# Changelog

## 0.4.0
- Fixed `create element ... called ...` parsing.
- Added friendly typo handling such as `reapeat` -> `repeat`.
- Added multiline array/object literals.
- Added array item/object CRUD commands.
- Added direct CRUD operations on arrays/objects stored in localStorage/sessionStorage.
- Added `wait(seconds)`, `after ...`, `every ...`, and timer cancellation.
- Added native array aliases such as `concat` and array copy.
- Kept JavaScript interop and browser-only execution.

# SimpliJS v0.3.0

## Added

- `ask()` and `askYesNo()` browser prompt helpers
- Math helpers: `random`, `randomBetween`, `round`, `roundUp`, `roundDown`, `absolute`, `power`, `squareRoot`, `min`, `max`, `pi`
- Date/time helpers: `now`, `today`, `timeNow`, `currentYear`, `dateIn`, `timeIn`, `dateTimeIn`
- Country aliases plus direct IANA time-zone support for date/time helpers
- Form input value, checked state, type, validity, validation message and form-data access
- DOM actions for validation, focus, blur, click, selection, submit and reset
- Friendly source-line-first compiler diagnostics and likely keyword suggestions
- Runtime warnings for invalid selectors, missing elements and unknown time zones
- Generic static Object/Array method access
- `<simplijs>` as the primary browser tag, with `<easyjs>` kept as a compatibility alias

## Runtime model

Everything still compiles and executes in the visitor's browser. The CDN artifact has no SimpliJS server dependency.
