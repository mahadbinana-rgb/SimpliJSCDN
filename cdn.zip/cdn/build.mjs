import fs from 'node:fs/promises';
import path from 'node:path';

const root = new URL('.', import.meta.url).pathname;
const files = [
  'src/errors.js',
  'src/utils.js',
  'src/parser.js',
  'src/generator.js',
  'src/compiler.js',
  'src/browser.js'
];

// A tiny purpose-built browser bundle. This keeps the CDN artifact dependency-free.
const modules = [];
for (const file of files) {
  const text = await fs.readFile(path.join(root, file), 'utf8');
  modules.push(`// ---- ${file} ----\n${text}`);
}

let bundle = modules.join('\n\n');
bundle = bundle.replace(/import .*?;\n/g, '').replace(/export\s+(?=(class|function|const|let|var))/g, '');
bundle = `(function(){\n'use strict';\n${bundle}\n})();\n`;
await fs.mkdir(path.join(root, 'dist'), { recursive: true });
await fs.writeFile(path.join(root, 'dist/simplijs.js'), bundle, 'utf8');
await fs.writeFile(path.join(root, 'dist/simplijs.min.js'), minifySimple(bundle), 'utf8');
console.log('Built dist/simplijs.js and dist/simplijs.min.js');

function minifySimple(code) {
  return code
    .replace(/\/\/[^\n]*\n/g, '\n')
    .replace(/\n\s+/g, '\n')
    .replace(/\s{2,}/g, ' ')
    .trim() + '\n';
}
